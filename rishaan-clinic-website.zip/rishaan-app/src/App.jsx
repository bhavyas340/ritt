import RishaanClinic from './components/RishaanClinic'

export default function App() {
  return (
    <>
      <a href="#main-content" className="skip-link">Skip to main content</a>
      <RishaanClinic />
    </>
  )
}
