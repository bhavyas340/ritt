import { useState } from 'react'
import styles from './RishaanClinic.module.css'

const TIME_SLOTS = ['9:00 AM', '10:00 AM', '11:00 AM', '2:00 PM', '6:00 PM', '7:00 PM', '8:00 PM', '9:00 PM']

const REVIEWS = [
  { name: 'Priya M.', text: 'Really good doctor with good experience.', stars: 5 },
  { name: 'Rahul S.', text: 'Highly recommend Rishaan clinic because of cleanliness and behaviour.', stars: 5 },
  { name: 'Sneha K.', text: 'The clinic feels welcoming, and the consultation experience is excellent.', stars: 5 },
]

const SERVICES = [
  ['🫀', 'Chronic Conditions', 'Expert management of hypertension, diabetes, and long-term conditions.'],
  ['🌿', 'Preventive & Holistic Care', 'Lifestyle guidance and health screenings for the whole family.'],
  ['🤧', 'Allergy Management', 'Diagnosis and personalised treatment for allergies and sensitivities.'],
  ['👨‍👩‍👧', 'Family Medicine', 'Comprehensive care for all ages — children to seniors.'],
  ['📋', 'Patient Education', 'We empower you to actively participate in your own health journey.'],
  ['💊', 'General Consultations', 'Walk-ins & appointments for common illness, prescriptions & follow-ups.'],
]

const SPECIALITIES = [
  'Hypertension Management', 'Allergy Treatment',
  'Family Medicine', 'Preventive Health',
  'Chronic Condition Care', 'Patient Education',
]

export default function RishaanClinic() {
  const [tab, setTab]             = useState('home')
  const [menuOpen, setMenuOpen]   = useState(false)
  const [booking, setBooking]     = useState({ name: '', phone: '', reason: '', date: '', time: '' })
  const [bookingDone, setBookingDone] = useState(false)
  const [contact, setContact]     = useState({ name: '', email: '', message: '' })
  const [contactDone, setContactDone] = useState(false)

  const canBook    = booking.name && booking.phone && booking.date && booking.time
  const canContact = contact.name && contact.email && contact.message

  const nav = (t) => {
    setTab(t)
    setMenuOpen(false)
    setBookingDone(false)
    setContactDone(false)
    window.scrollTo({ top: 0, behavior: 'smooth' })
  }

  return (
    <div className={styles.root}>

      {/* ── HEADER ─────────────────────────────── */}
      <header className={styles.header}>
        <button className={styles.logo} onClick={() => nav('home')} aria-label="Go to home">
          <div className={styles.logoIcon}>R</div>
          <div>
            <div className={styles.logoName}>Rishaan Health Clinic</div>
            <div className={styles.logoSub}>Dr. Shweta Wagh-Aher · Hinjawadi, Pune</div>
          </div>
        </button>

        {/* Desktop nav */}
        <nav className={styles.desktopNav} aria-label="Main navigation">
          {[['home','Home'],['about','About'],['booking','Book Appointment'],['contact','Contact']].map(([t,l]) => (
            <button key={t} className={`${styles.navBtn} ${tab===t ? styles.navActive : ''}`} onClick={() => nav(t)}>{l}</button>
          ))}
        </nav>

        <a href="tel:07498110885" className={styles.desktopCall}>
          <button className={styles.btnRed} style={{ padding: '10px 20px', fontSize: 12 }}>📞 074981 10885</button>
        </a>

        {/* Hamburger */}
        <button
          className={styles.hamburger}
          onClick={() => setMenuOpen(!menuOpen)}
          aria-label="Toggle menu"
          aria-expanded={menuOpen}
        >
          <span /><span /><span />
        </button>
      </header>

      {/* Mobile nav drawer */}
      {menuOpen && (
        <nav className={styles.mobileMenu} aria-label="Mobile navigation">
          {[['home','🏠 Home'],['about','👩‍⚕️ About Dr. Shweta'],['booking','📅 Book Appointment'],['contact','📞 Contact Us']].map(([t,l]) => (
            <button key={t} className={`${styles.mobileNavBtn} ${tab===t ? styles.navActive : ''}`} onClick={() => nav(t)}>{l}</button>
          ))}
          <a href="tel:07498110885" style={{ textDecoration: 'none', marginTop: 8 }}>
            <button className={`${styles.btnRed} ${styles.btnFull}`}>Call: 074981 10885</button>
          </a>
        </nav>
      )}

      {/* ── MAIN ──────────────────────────────── */}
      <main id="main-content" className={styles.main}>

        {/* HOME */}
        {tab === 'home' && (
          <div className={styles.fadeUp}>

            {/* Hero */}
            <section className={styles.heroGrid} aria-label="Welcome">
              <div>
                <span className={styles.badge}>General Practice · Hinjawadi, Pune</span>
                <h1 className={styles.h1}>
                  Healthcare That<br />
                  <span className={styles.red}>Puts You First</span>
                </h1>
                <p className={styles.heroText}>
                  Welcome to Rishaan Health Clinic in the heart of Hinjawadi Phase 3, Pune.
                  Dr. Shweta Wagh-Aher brings warmth, expertise, and a holistic approach to every consultation.
                </p>
                <div className={styles.ratingChip} style={{ marginBottom: 28 }}>
                  <span aria-label="Rating 4.9 out of 5">★ 4.9</span>
                  <span style={{ fontWeight: 400, color: '#888' }}>· 37 verified Google reviews</span>
                </div>
                <div className={styles.heroBtns}>
                  <button className={styles.btnRed} onClick={() => nav('booking')}>Book Appointment</button>
                  <button className={styles.btnGhost} onClick={() => nav('about')}>About Dr. Shweta</button>
                </div>
              </div>

              <div className={styles.heroHours}>
                <div className={styles.hoursPanel}>
                  <div className={styles.hoursTitle}>Clinic Hours</div>
                  {[
                    ['Monday – Saturday', 'Open · Closes 10:00 PM'],
                    ['Sunday', 'Open · (by appointment)'],
                    ['Emergency', 'Call 074981 10885'],
                  ].map(([day, hrs]) => (
                    <div key={day} className={styles.hoursRow}>
                      <span>{day}</span><span className={styles.hoursVal}>{hrs}</span>
                    </div>
                  ))}
                  <div className={styles.hoursDivider} />
                  <address className={styles.hoursAddress}>
                    📍 Megapolis Saffron, near Megapolis Circle,<br />
                    Phase 3, Hinjawadi, Pune – 411057
                  </address>
                </div>
              </div>
            </section>

            {/* Stats */}
            <section className={styles.statsGrid} aria-label="Clinic stats">
              {[['★ 4.9','Google Rating'],['37+','Happy Patients'],['10 PM','Open Until']].map(([n,l]) => (
                <div key={l} className={styles.statBox}>
                  <div className={styles.statNum}>{n}</div>
                  <div className={styles.statLabel}>{l}</div>
                </div>
              ))}
            </section>

            {/* Services */}
            <section aria-label="Services" style={{ marginBottom: 64 }}>
              <div className={styles.sectionHead}>
                <span className={styles.badge}>What We Treat</span>
                <h2 className={styles.h2}>Our Specialisations</h2>
              </div>
              <div className={styles.servicesGrid}>
                {SERVICES.map(([icon, title, desc]) => (
                  <article key={title} className={styles.card}>
                    <div className={styles.serviceIcon} aria-hidden="true">{icon}</div>
                    <h3 className={styles.cardTitle}>{title}</h3>
                    <p className={styles.cardDesc}>{desc}</p>
                  </article>
                ))}
              </div>
            </section>

            {/* Reviews */}
            <section aria-label="Patient reviews" style={{ marginBottom: 64 }}>
              <div className={styles.sectionHead}>
                <span className={styles.badge}>Patient Voices</span>
                <h2 className={styles.h2}>What Patients Say</h2>
              </div>
              <div className={styles.reviewsGrid}>
                {REVIEWS.map((r, i) => (
                  <article key={i} className={styles.card}>
                    <div aria-label={`${r.stars} stars`} style={{ marginBottom: 10 }}>
                      {'★'.repeat(r.stars).split('').map((s,j) => <span key={j} className={styles.star}>{s}</span>)}
                    </div>
                    <blockquote className={styles.reviewText}>"{r.text}"</blockquote>
                    <footer className={styles.reviewAuthor}>— {r.name}</footer>
                  </article>
                ))}
              </div>
            </section>

            {/* CTA */}
            <section className={styles.ctaBanner} aria-label="Call to action">
              <div>
                <div className={styles.ctaTitle}>Ready to visit us?</div>
                <div className={styles.ctaSub}>Open till 10 PM — walk in or book ahead.</div>
              </div>
              <div className={styles.ctaBtns}>
                <button className={styles.btnRed} onClick={() => nav('booking')}>Book Online</button>
                <a href="tel:07498110885" style={{ textDecoration: 'none' }}>
                  <button className={styles.btnGhostWhite}>Call Now</button>
                </a>
              </div>
            </section>
          </div>
        )}

        {/* ABOUT */}
        {tab === 'about' && (
          <div className={`${styles.fadeUp} ${styles.aboutGrid}`}>
            <div>
              <div className={styles.docPanel}>
                <div className={styles.docBg} aria-hidden="true">SW</div>
                <div className={styles.docLabel}>Lead Physician</div>
                <h1 className={styles.docName}>Dr. Shweta Wagh-Aher</h1>
                <div className={styles.docRole}>General Practitioner · MBBS</div>
                <div className={styles.docDivider} />
                {[['Speciality','General & Family Medicine'],['Focus','Holistic & Preventive Care'],['Location','Hinjawadi Phase 3, Pune']].map(([k,v]) => (
                  <div key={k} style={{ marginBottom: 14 }}>
                    <div className={styles.docKey}>{k}</div>
                    <div className={styles.docVal}>{v}</div>
                  </div>
                ))}
              </div>
              <div className={`${styles.ratingChip} ${styles.ratingFull}`}>
                <span style={{ fontSize: 18 }}>★ 4.9</span>
                <span style={{ fontWeight: 400, color: '#888' }}>· 37 Google reviews</span>
              </div>
            </div>

            <div>
              <span className={styles.badge} style={{ marginBottom: 16, display: 'inline-block' }}>About the Doctor</span>
              <h2 className={styles.aboutH2}>A Physician Who Listens, Guides &amp; Heals</h2>
              <p className={styles.aboutText}>
                Dr. Shweta Wagh-Aher is a seasoned general practitioner at Rishaan Health Clinic,
                nestled in Hinjawadi Phase 3, Pune. Specialising in holistic and preventative care
                for the whole family, she expertly manages chronic conditions like{' '}
                <strong>hypertension</strong> and <strong>allergies</strong>.
              </p>
              <p className={styles.aboutText}>
                At Rishaan Health Clinic, patient education and collaboration are at the heart of
                every visit — empowering you to actively participate in your well-being. Step into
                a warm, welcoming environment where personalised care meets comprehensive medicine.
              </p>
              <div className={styles.specialityGrid}>
                {SPECIALITIES.map(tag => (
                  <div key={tag} className={styles.specialityTag}>{tag}</div>
                ))}
              </div>
              <button className={styles.btnRed} onClick={() => nav('booking')}>
                Book a Consultation →
              </button>
            </div>
          </div>
        )}

        {/* BOOKING */}
        {tab === 'booking' && (
          <div className={styles.fadeUp} style={{ maxWidth: 580, margin: '0 auto' }}>
            <div className={styles.sectionHead}>
              <span className={styles.badge}>Appointments</span>
              <h1 className={styles.h2}>Book an Appointment</h1>
              <p className={styles.subText}>With Dr. Shweta Wagh-Aher · Rishaan Health Clinic, Hinjawadi</p>
            </div>

            {!bookingDone ? (
              <div className={styles.card} style={{ padding: '36px' }}>
                <div className={styles.formStack}>
                  <div>
                    <label className={styles.label}>Full Name *</label>
                    <input className={styles.input} placeholder="Your full name" value={booking.name}
                      onChange={e => setBooking({...booking, name: e.target.value})} autoComplete="name" />
                  </div>
                  <div>
                    <label className={styles.label}>Phone Number *</label>
                    <input className={styles.input} type="tel" placeholder="+91 98765 43210" value={booking.phone}
                      onChange={e => setBooking({...booking, phone: e.target.value})} autoComplete="tel" />
                  </div>
                  <div>
                    <label className={styles.label}>Reason for Visit</label>
                    <select className={styles.input} value={booking.reason} onChange={e => setBooking({...booking, reason: e.target.value})}>
                      <option value="">— Select reason (optional) —</option>
                      {['General Consultation','Hypertension / BP Check','Allergy Treatment','Chronic Condition Follow-up','Child Health / Paediatrics','Preventive Health Check','Other'].map(o => <option key={o}>{o}</option>)}
                    </select>
                  </div>
                  <div>
                    <label className={styles.label}>Preferred Date *</label>
                    <input className={styles.input} type="date" value={booking.date}
                      onChange={e => setBooking({...booking, date: e.target.value})}
                      min={new Date().toISOString().split('T')[0]} />
                  </div>
                  <div>
                    <label className={styles.label}>Preferred Time *</label>
                    <div className={styles.slotsGrid}>
                      {TIME_SLOTS.map(s => (
                        <button key={s} className={`${styles.slot} ${booking.time===s ? styles.slotPicked : ''}`}
                          onClick={() => setBooking({...booking, time: s})} aria-pressed={booking.time===s}>
                          {s}
                        </button>
                      ))}
                    </div>
                  </div>
                  <button className={`${styles.btnRed} ${styles.btnFull}`}
                    style={{ opacity: canBook ? 1 : 0.45 }} onClick={() => canBook && setBookingDone(true)}>
                    Confirm Appointment
                  </button>
                  <p className={styles.callNote}>
                    Or call: <a href="tel:07498110885" className={styles.callLink}>074981 10885</a>
                  </p>
                </div>
              </div>
            ) : (
              <div className={`${styles.successBox} ${styles.fadeUp}`}>
                <div className={styles.successIcon}>✓</div>
                <div className={styles.successTitle}>Appointment Requested!</div>
                <p className={styles.successText}>Thank you, <strong>{booking.name}</strong>!</p>
                <p className={styles.successText}>Dr. Shweta Wagh-Aher · {booking.date} at {booking.time}</p>
                <p className={styles.successNote}>We'll confirm via call to {booking.phone}.</p>
                <button className={styles.btnGhost} onClick={() => { setBookingDone(false); setBooking({ name:'', phone:'', reason:'', date:'', time:'' }) }}>
                  Book Another
                </button>
              </div>
            )}
          </div>
        )}

        {/* CONTACT */}
        {tab === 'contact' && (
          <div className={`${styles.fadeUp} ${styles.contactGrid}`}>
            <div>
              <span className={styles.badge} style={{ marginBottom: 16, display: 'inline-block' }}>Find Us</span>
              <h1 className={styles.aboutH2}>Get in Touch</h1>
              <p className={styles.aboutText}>
                We're happy to hear from you — whether it's a health question, appointment query, or feedback.
              </p>
              <div className={styles.infoList}>
                {[
                  ['📍','Address','Megapolis Saffron, near Megapolis Circle,\nPhase 3, Hinjawadi Rajiv Gandhi Infotech Park,\nHinjawadi, Pune – 411057'],
                  ['📞','Phone','074981 10885'],
                  ['🕐','Hours','Open daily · Closes 10:00 PM'],
                  ['🌍','Areas Served','Hinjawadi, Wakad, Baner, Balewadi & nearby Pune areas'],
                ].map(([icon,lbl,val]) => (
                  <div key={lbl} className={styles.infoRow}>
                    <span className={styles.infoIcon} aria-hidden="true">{icon}</span>
                    <div>
                      <div className={styles.infoLabel}>{lbl}</div>
                      <div className={styles.infoVal} style={{ whiteSpace: 'pre-line' }}>{val}</div>
                    </div>
                  </div>
                ))}
              </div>
              <div className={styles.ratingNote}>
                <div className={styles.ratingNoteTitle}>⭐ 4.9 Rating on Google</div>
                <div className={styles.ratingNoteText}>Trusted by 37+ patients in Hinjawadi & surrounding areas.</div>
              </div>
            </div>

            <div>
              {!contactDone ? (
                <div className={styles.card} style={{ padding: '36px' }}>
                  <div className={styles.cardTitle} style={{ fontSize: 22, marginBottom: 22 }}>Send Us a Message</div>
                  <div className={styles.formStack}>
                    <div>
                      <label className={styles.label}>Full Name</label>
                      <input className={styles.input} placeholder="Your name" value={contact.name}
                        onChange={e => setContact({...contact, name: e.target.value})} autoComplete="name" />
                    </div>
                    <div>
                      <label className={styles.label}>Email Address</label>
                      <input className={styles.input} type="email" placeholder="you@email.com" value={contact.email}
                        onChange={e => setContact({...contact, email: e.target.value})} autoComplete="email" />
                    </div>
                    <div>
                      <label className={styles.label}>Message</label>
                      <textarea className={styles.input} rows={5} placeholder="How can we help you?"
                        value={contact.message} onChange={e => setContact({...contact, message: e.target.value})}
                        style={{ resize: 'vertical' }} />
                    </div>
                    <button className={`${styles.btnRed} ${styles.btnFull}`}
                      style={{ opacity: canContact ? 1 : 0.45 }} onClick={() => canContact && setContactDone(true)}>
                      Send Message
                    </button>
                  </div>
                </div>
              ) : (
                <div className={`${styles.successBox} ${styles.fadeUp}`}>
                  <div className={styles.successIcon}>✓</div>
                  <div className={styles.successTitle}>Message Sent!</div>
                  <p className={styles.successText}>Thank you, <strong>{contact.name}</strong>.</p>
                  <p className={styles.successNote}>We'll reply to <strong>{contact.email}</strong> shortly.</p>
                  <button className={styles.btnGhost} onClick={() => { setContactDone(false); setContact({ name:'', email:'', message:'' }) }}>
                    Send Another
                  </button>
                </div>
              )}
            </div>
          </div>
        )}
      </main>

      {/* ── FOOTER ─────────────────────────────── */}
      <footer className={styles.footer}>
        <div className={styles.footerInner}>
          <div className={styles.footerName}>Rishaan Health Clinic</div>
          <address className={styles.footerMid}>
            Dr. Shweta Wagh-Aher · Hinjawadi Phase 3, Pune ·{' '}
            <a href="tel:07498110885" className={styles.callLink}>074981 10885</a>
          </address>
          <div className={styles.footerCopy}>© 2025 Rishaan Health Clinic</div>
        </div>
      </footer>

      {/* Sticky mobile call strip */}
      <a href="tel:07498110885" className={styles.mobileCallStrip} aria-label="Call Rishaan Health Clinic">
        📞 Call Us: 074981 10885
      </a>
    </div>
  )
}
